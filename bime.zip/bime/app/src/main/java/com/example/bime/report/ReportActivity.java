package com.example.bime.report;

import android.support.v7.app.AppCompatActivity;

public class ReportActivity extends AppCompatActivity {
}
