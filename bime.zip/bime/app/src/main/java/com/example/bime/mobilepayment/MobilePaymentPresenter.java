package com.example.bime.mobilepayment;

public class MobilePaymentPresenter {
}
