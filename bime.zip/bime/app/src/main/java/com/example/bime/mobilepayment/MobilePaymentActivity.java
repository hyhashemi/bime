package com.example.bime.mobilepayment;

import android.support.v7.app.AppCompatActivity;

public class MobilePaymentActivity extends AppCompatActivity {
}
